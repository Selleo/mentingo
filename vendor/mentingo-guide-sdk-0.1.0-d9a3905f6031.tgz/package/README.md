# @mentingo/guide-sdk

Thin generated Axios client for Mentingo's self-onboarding service. This private
package supports authenticated drafts, media preparation, Bunny upload grants,
verification/indexing operations and explicit publication. Public clients can
search and resolve compatible tutorials without a key. Drafts remain private
until verification/indexing succeeds and `publishRevision` activates them.

The future default origin is `https://help.mentingo.com`; this change does not
deploy that service. Use an explicit local origin during local validation.

```typescript
import { createGuideClient } from '@mentingo/guide-sdk';

const guide = createGuideClient({
  baseURL: process.env.GUIDE_API_URL,
  apiKey: process.env.GUIDE_PUBLISH_API_KEY,
});

const draft = await guide.publishing.createRevision(
  'course-authoring.edit-curriculum',
  { metadata, expectedPublishedRevisionId: null },
  { idempotencyKey: 'release-1-course-curriculum-en' },
);
const current = await guide.publishing.getRevision(draft.id);
const updated = await guide.publishing.updateRevision(
  current.id,
  updatedMetadata,
  { expectedVersion: current.version },
);
```

`metadata`/`updatedMetadata` use the generated `RevisionMetadata` contract, and
`createRevision` returns a generated `Revision`, not a background operation. See
the [synthetic fixture](../../apps/helpdesk/tests/fixtures/draft.json) for the full
metadata shape. Updating replaces the complete metadata document. The SDK sends
a strong quoted `If-Match` version; stale edits return a typed conflict. Creation
retries with the same idempotency key/payload replay the original creation result;
use `getRevision` for current state after later edits. Use a new key for a new
creation request. There is no automatic retry or polling.

## Prepare a direct Bunny upload

```typescript
import { MediaContentType, OperationStatus } from '@mentingo/guide-sdk';

const signal = AbortSignal.timeout(120_000);
let operation = await guide.publishing.prepareMedia(
  updated.id,
  { contentType: MediaContentType.VideoMp4, expectedSizeBytes: fileSize, expectedSha256: sha256 },
  { idempotencyKey: 'release-1-course-curriculum-en-media', expectedVersion: updated.version, signal },
);

// Poll explicitly with your workflow's bounded retry/deadline policy.
for (let attempt = 0; attempt < 60 &&
     [OperationStatus.Queued, OperationStatus.Running].includes(operation.status); attempt += 1) {
  await new Promise((resolve) => setTimeout(resolve, 1_000));
  operation = await guide.publishing.getOperation(operation.id, { signal });
}
if (operation.status !== OperationStatus.Succeeded) {
  throw new Error(`Media preparation did not succeed: ${operation.status}`);
}
const grant = await guide.publishing.createUploadAuthorization(updated.id, { signal });
// Pass grant.endpoint, grant.headers and grant.metadata to your existing TUS client.
// That client uploads the file directly to Bunny, never through the Helpdesk API.
```

`prepareMedia` requires both an idempotency key and the current strong edit
version; it returns a `MediaOperation`. `getOperation` reads status once.
`retryOperation(operation.id)` explicitly requests retry of a recoverable failed
operation; it does not poll or retry automatically. An upload grant maps directly
to the generated `UploadAuthorization`, including its Bunny headers and metadata.
Do not log those grants or send the Helpdesk publishing key to Bunny.

Grants last **3,600 seconds**. Requesting a refreshed grant keeps the same video
GUID and does not extend an existing TUS upload resource's own lifetime. File size
and SHA256 are publisher expectations returned with the grant; the authorization
signature does not enforce or verify those expectations. Grant issuance/preparation
success also does not establish completed upload, playable encoding or publication.

## Finalize, publish and search

After the existing TUS client has completed the direct upload, request media
verification and indexing. Polling remains explicit and bounded by your workflow.
Success does not itself publish the draft:

```typescript
const uploaded = await guide.publishing.getRevision(updated.id);
let finalization = await guide.publishing.finalizeRevision(uploaded.id, {
  expectedVersion: uploaded.version,
  idempotencyKey: 'release-1-course-curriculum-en-finalize',
  signal,
});
for (let attempt = 0; attempt < 60 &&
     [OperationStatus.Queued, OperationStatus.Running].includes(finalization.status); attempt += 1) {
  await new Promise((resolve) => setTimeout(resolve, 1_000));
  finalization = await guide.publishing.getFinalizationOperation(finalization.id, { signal });
}
if (finalization.status !== OperationStatus.Succeeded) {
  throw new Error(`Finalization did not succeed: ${finalization.status}`);
}
const published = await guide.publishing.publishRevision(uploaded.id, {
  expectedVersion: finalization.revisionVersion,
  signal,
});

// Public viewers and self-hosted installations do not receive a publishing key.
const viewer = createGuideClient({ baseURL: process.env.GUIDE_API_URL });
const results = await viewer.search.query({
  query: 'How do I add a lesson?', appVersion: '1.2.0', language: 'en',
  features: ['course-editor'], pageKey: 'admin.course.curriculum',
});
const tutorial = await viewer.tutorials.get(published.tutorialKey, {
  appVersion: '1.2.0', language: 'en', features: 'course-editor',
});
const domains = await viewer.tutorials.domains();
```

`finalizeRevision` uses both `Idempotency-Key` and a strong version precondition;
`publishRevision` uses the version from the successful finalization operation.
`retryFinalizationOperation(id)` is an explicit caller decision for a recoverable
failed operation. The SDK never silently polls, retries or publishes. These calls
carry JSON/control metadata, not video bytes. Finalization requires authoritative
Bunny verification evidence and the configured embedding provider; upload/grant
success alone is insufficient.

Public search and tutorial methods send no Authorization header, even if the same
factory was configured with a publishing key. `SearchResponse.mode` distinguishes
hybrid retrieval, keyword fallback and browsing. Public tutorial data contains
Bunny URLs and chapter bounds, without publisher-only provenance. Search accepts
an array of feature keys; the generated tutorial GET query uses comma-separated
`features`. Domain labels are metadata/suggestions, not required UI filters.

## Configuration and errors

Configuration is explicit: `baseURL`, optional `apiKey`, `timeoutMs` and an
optional Axios adapter for tests. The SDK never reads environment variables. JSON/control requests have fixed limits:
8 MiB per response and 2 MiB per request body. Redirects are disabled, so credentials
and queries stay at the configured origin. Video upload and playback bytes bypass
this SDK and these limits entirely.
Publishing methods reject locally when `apiKey` is absent. The generated
security worker sends it only to secured publishing routes, never health checks.
Do not distribute publishing keys to browsers or self-hosted viewers.

Per-call options accept `signal`; creation requires `idempotencyKey`, and updates
require a positive safe-integer `expectedVersion`. Media preparation requires
both options; finalization does too. Publication requires `expectedVersion`.
Operation, upload-grant and public retrieval methods accept `signal`. `GuideApiError` exposes safe
server code/message, HTTP status, request ID, retryability and Retry-After without
retaining Axios configuration or credentials. Cancellation remains recognizable
through Axios `isCancel`.

Rust DTOs/handlers are the source of truth. From the repo root:

```sh
cargo +1.94.1 run --locked --manifest-path apps/helpdesk/Cargo.toml -- openapi apps/helpdesk/openapi.json
pnpm --filter @mentingo/guide-sdk generate:client
pnpm --filter @mentingo/guide-sdk build
pnpm --filter @mentingo/guide-sdk typecheck
pnpm --filter @mentingo/guide-sdk test
```

Generation uses Core's `swagger-typescript-api@13.0.12 --axios` toolchain. Do not
edit generated code. `./types` exports curated browser-safe generated DTOs. Keep
the package private until the public v1 contract and release checks are ready.
Video upload/playback bytes go directly to Bunny; SDK service calls carry
JSON metadata only.
